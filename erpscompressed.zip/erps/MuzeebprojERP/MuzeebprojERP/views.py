from django.shortcuts import render, redirect
from MuzeebprojERP.forms import CreateUserForm
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.core.mail import send_mail
from MuzeebprojERP.settings import EMAIL_HOST_USER
import random
from django.http import HttpResponse
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.models import User

@csrf_exempt
def VerifyOTP(request):
    if request.method == "POST":
        userotp = request.POST.get('otp')
        email = request.POST.get('email')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')

        if password1 == password2:
            form = User(first_name = first_name, last_name = last_name, email = email, username = username, password = password1)
            form.save()
        print("OTP: ", userotp)
    return JsonResponse({'data': 'data'}, status=200)

def SignUpView(request):
    form = CreateUserForm()
    if request.method == "POST":
        email = request.POST.get('email')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        

        form = CreateUserForm(request.POST)

        if form.is_valid():
            #form.save()
            otp = random.randint(100000, 999999)
            send_mail("User Data: ", f"Verify Your Mail by OTP: /n {otp}", EMAIL_HOST_USER, [email], fail_silently=True)
            messages.success(request, 'User Saved Successfully')
            return render(request,'webssite/verify.html',{'otp' : otp, 'first_name': first_name, 'last_name': last_name, 'email': email, 'username': username, 'password1': password1, 'password2': password2})

        else:
            print('Form Error: ', form.errors)
            messages.error(request, form.errors)
    context = {'form':form}
    return render(request,'webssite/signup.html',context)




@csrf_exempt
def VerifyLoginOTP(request):
    if request.method == "POST":
        userotp = request.POST.get('otp')
        username = request.POST.get('username')
        #email = request.POST.get('email')
        password = request.POST.get('password')
        
        user = authenticate(request,username=username, password=password)
        if user is not None:
            login(request,user)
            print("Login Done")
        
        print("OTP: ", userotp)
    return JsonResponse({'data': 'data'}, status=200)



def LoginView(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        email = User.objects.get(username=username).email

        print("Username:", username)
        print("Password:", password)
        print("Email: ", email)

        user = authenticate(request,username=username, password=password)
        if user is not None:
            otp = random.randint(100000, 999999)
            send_mail("User Data: ", f"Verify Your Mail by OTP: /n {otp}", EMAIL_HOST_USER, [email], fail_silently=True)
            messages.success(request, 'User Saved Successfully')
            return render(request,'webssite/verifyLogin.html',{'otp' : otp,'username': username, 'password': password})
  

         #   login(request,user)
          #  print("Login Done")
           # messages.success(request, 'Login Successful')
            #return redirect('/')
        else:
            messages.error(request, 'Invalid Entry')
          #  print("Some error")
        otp = random.randint(100000, 999999)
        send_mail("User Data: ", f"Verify Your Mail by OTP: /n {otp}", EMAIL_HOST_USER, [email], fail_silently=True)
        messages.success(request, 'User Saved Successfully')
        return render(request,'webssite/verifyLogin.html',{'otp' : otp,'username': username, 'password': password})
  


    context={}
    return render(request, 'webssite/login.html', context)

def LogoutView(request):
    logout(request)
    print('Logout Successfull')
    messages.success(request, 'Logout Successful')
    return redirect('login')


def ForgetPassword(request):
    if request.method=="POST":
        email = request.POST.get("email")
        print("Email: ",email)

        if User.objects.filter(email=email).exists():
            user = User.objects.get(email=email)
            print("Users Exist")
            send_mail("Reset Your Password: ", f"Hey user: {user} to reset password, click on the given link \n http://127.0.0.1:8000/newpasswordpage/{user}/", EMAIL_HOST_USER, [email], fail_silently=True)
            return HttpResponse("Password Reset Link Sent to your Email")
        return render(request, 'webssite/forget_password.html')
    return render(request, 'webssite/forget_password.html')



def NewPasswordPage(request, user):
    userid = User.objects.get(username = user)
    print("UserId:", userid)
    if request.method=="POST":
        pass1 = request.POST.get("password1")
        pass2 = request.POST.get("password2")
        print('Pass1 and Pass2', pass1 , pass2)
        if pass1 == pass2:
            userid.set_password(pass1)
            userid.save()
            return HttpResponse("Password Reset")

        

    return render(request, 'webssite/new_password.html')

