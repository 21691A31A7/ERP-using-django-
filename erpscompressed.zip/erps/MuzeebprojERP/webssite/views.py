from django.shortcuts import render
from django.contrib.auth.models import User


def Index(request):
    return render(request, 'webssite/dashboard.html')


def ShowStaff(request):
    data = User.objects.all()

    context={'data' : data}
    return render(request, 'webssite/showStaff.html', context)



def ViewStaffData(request,id):
    data = User.objects.get(id=id)

    context={'data' : data}
    return render(request, 'webssite/viewStaffdata.html', context)