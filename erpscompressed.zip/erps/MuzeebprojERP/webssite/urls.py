from django.urls import path
#
# from webssite.views import Index
from webssite import views

urlpatterns=[
    path('', views.Index, name='index'),
    path('ShowStaff/', views.ShowStaff, name='showStaff'),
    path('ShowStaffData/<int:id>/', views.ViewStaffData, name='viewStaffData'),
]