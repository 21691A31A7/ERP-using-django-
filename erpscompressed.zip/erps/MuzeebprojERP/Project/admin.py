from django.contrib import admin
from Project.models import  ProjectModel, ProjectCategoryModel

admin.site.register(ProjectModel)
admin.site.register(ProjectCategoryModel)
